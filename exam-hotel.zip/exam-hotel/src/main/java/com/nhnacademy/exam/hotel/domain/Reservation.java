package com.nhnacademy.exam.hotel.domain;


public class Reservation {
}
