package com.nhnacademy;

public class FibonacciJSON {
    public static void main(String[] args) {
        System.out.println(args[0]);
    }
}
