package com.nhnacademy;

public class Fibonacci {

}